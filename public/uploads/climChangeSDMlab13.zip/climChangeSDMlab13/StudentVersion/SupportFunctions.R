#' Train a Maxent Species Distribution Model and Project Future Suitability
#' Roxygen summary created from ChatGPT. Code Written by Grant Foster
#'
#' This function trains a Maxent species distribution model (SDM) using WorldClim current and CMIP6 future bioclimatic data.
#' It projects environmental variables into PCA space, generates pseudo-absence points with a spatial buffer, and evaluates model performance (AUC). Suitability maps and summary statistics are output for both current and future climate scenarios.
#'
#' @param Occ A `data.frame` of occurrence records. Must contain columns: `decimalLatitude`, `decimalLongitude`, and `state`.
#' @param split A numeric proportion (default = 0.75) of data to use for training (vs. testing).
#' @param sp A character string specifying the species name used in plot titles and output file names.
#' @param plotstate A character string indicating which U.S. state to subset for plotting occurrences (default = "South Carolina").
#'
#' @details
#' Broadly, the function function performs the following steps:
#' \itemize{
#'   \item Downloads and crops WorldClim current and CMIP6 future bioclimatic data.
#'   \item Scales and projects environmental layers into PCA space.
#'   \item Extracts occurrence points and generates spatially buffered pseudo-absence points.
#'   \item Prepares training and testing datasets using presence and pseudo-absence points.
#'   \item Trains a Maxent model and evaluates AUC performance.
#'   \item Produces suitability maps for both current and future conditions.
#'   \item Saves figures as PDFs and plots in the current graphics device.
#' }
#'
#' Output includes:
#' \itemize{
#'   \item PDF maps of current and future predicted distributions.
#'   \item On-screen raster plots with overlaid occurrence points and AUC and area statistics.
#'   \item Percentage of the state area with suitability > 0.75 under current and future climates.
#' }
#'
#' @return No object is returned, but plots are produced and PDFs are saved to the working directory.

trainMaxentfull <- function(Occ, split=0.75, sp="SpeciesName", plotstate="South Carolina"){
  if(c("decimalLatitude") %in% colnames(Occ)==FALSE | "decimalLongitude" %in% colnames(Occ)==FALSE){
    stop("Missing or misnamed Lat-Long columns!")
  }
  
  if(c("state") %in% colnames(Occ)==FALSE){
    stop("Missing a state column")
  }
  
  if(class(Occ)[[1]]!="data.frame"){
    stop("Occ should be a data.frame")
  }
  
  Clima <- geodata::worldclim_global("worldclim", var="bio", res=2.5)
  Future <- cmip6_world(model="CNRM-CM6-1", ssp="370", time="2061-2080", var="bio", res=2.5, path=".")
  
  #SC <- terra::crop(Clima, ext(-84, -78, 32, 35.5))
  SC <- terra::crop(Clima, ext(-100, -70, 10, 40))
  #SC_Future <- terra::crop(Future, ext(-84, -78, 32, 35.5))
  SC_Future <- terra::crop(Future, ext(-100, -70, 10, 40))
  
  Climastack <- raster::stack(SC)
  #################TESTING
  
  # Extract the scaling parameters from Clima
  SC_scaled <- scale(as.data.frame(values(SC)))
  center_values <- attr(SC_scaled, "scaled:center")
  scale_values <- attr(SC_scaled, "scaled:scale")
  
  # Save the scaling parameters
  Climastack <- scale(raster::stack(SC))
  Futurestack <- scale(raster::stack(SC_Future), center=center_values, scale=scale_values)
  #Futurestack <- raster::stack(SC_Future)
  
  EnvCoord<-na.omit(raster::rasterToPoints(Climastack)) #Make raster into long df of points
  PcaR<-EnvCoord[,-c(1:2)] #remove latlong for PCA
  #Scale transform 
  
  DPca <- prcomp(PcaR,retx=TRUE,center=T,scale=T) #run PCA on scaled data
  
  FutureCoord <- na.omit(raster::rasterToPoints(Futurestack)) #Make raster into long df of points
  FPcaR<-FutureCoord[,-c(1:2)] #remove latlong for PCA
  colnames(FPcaR) <- colnames(PcaR)
  FPca <- predict(DPca, FPcaR) #Project onto our existing PCA space
  
  #% of the variation explained
  NEixos<-length(summary(DPca)$importance[3,])
  CumVar<-summary(DPca)$importance[3,]
  VarEx<- data.frame(CumVar)
  
  #Getting the loadings and transforming it into a dataframe
  Eix<-as.data.frame(DPca$x) #Grab the PCA loadings
  FEix <- as.data.frame(FPca) #Grab the PCA loadings
  EixXY<-cbind(EnvCoord[,(1:2)],Eix) #re add back in the coordinates from earlier
  FEixXY<-cbind(FutureCoord[,(1:2)],FEix) #re add back in the coordinates from earlier
  
  sp::gridded(EixXY)<- ~x+y #Create large spatial pixels df (prep to reconvert to raster)
  sp::gridded(FEixXY)<- ~x+y
  
  PCAPr <-raster::stack(EixXY) #create a rasterstack for each 
  FPCAPr <-raster::stack(FEixXY) #create a rasterstack for each 
  
  raster.comb <-PCAPr[[1:(sum(VarEx<=0.95)+1)]] #only include the axis necessary to explain 95% of variation
  project.comb <- FPCAPr[[1:(sum(VarEx<=0.95)+1)]]
  
  
  SC_boundary <- rnaturalearth::ne_states(country = "United States of America", returnclass = "sf") |>
    subset(name == "South Carolina")
  # Convert to terra object
  SC_boundary_vect <- vect(SC_boundary)
  
  Occ_plot <- dplyr::filter(Occ, state==plotstate)
  Occ <- dplyr::select(Occ, "scientificName", "decimalLongitude", "decimalLatitude") %>% dplyr::filter(., is.na(decimalLatitude)==F)#Select just the Occ columns
  Occ['cells']<-terra::cellFromXY(object= Clima[[1]], xy = Occ[,2:3]) #Grab the occurrence cells
  #creating a 200km2 buffer to select the psudo-absence points
  Occ <- unique(Occ) #remove redundant records
  OccSf<-sf::st_as_sf(x=Occ[,2:3], coords = c("decimalLongitude",'decimalLatitude'), 
                      crs=sp::CRS("EPSG:4326")) #crs=sp::CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"))
  OccBuffer<-sf::st_buffer(OccSf, dist=20000) #Create buffer objects with 2deg (~20km) buffers
  OccBuffer<-sf::st_union(OccBuffer) #Merge buffer objects into one
  
  ##Masking the buffer so that it does not occur in the ocean
  OccBufferVect <- terra::vect(OccBuffer)
  OccBufferVect <- terra::project(OccBufferVect, crs(Clima))
  OccBufferRas <- terra::rasterize(x = OccBufferVect, y=Clima)
  OccBufferRas<- raster::mask(x = OccBufferRas, mask = Clima[[1]])
  
  ##Selecting the potential pseudo absence sites
  AllPseudo <- terra::as.points(OccBufferRas)
  AllPseudo <- raster::extract(x= Clima[[1]], AllPseudo[,1:2],cell=T)
  AllPseudo <-AllPseudo[-(which(AllPseudo$cell%in%Occ$cells)),] #remove true presence from potential psuedo points
  
  #Actually sample psuedoabsences
  PseudoA <- sample(x = AllPseudo$cell, size = nrow(Occ)) #Sample a number of psuedoA equal to # of occurances
  PseudoA<-as.data.frame(raster::xyFromCell(object = Clima[[1]], cell = PseudoA)) #Make a df
  
  #Now, train a Maxent model
  Occurrences<-cbind(Occ[,2:3], PseudoA[,1:2]) #bind into 4 cols; left is real, right is associated psuedo
  colnames(Occurrences)<-c('Long','Lat','x','y')
  
  
  id.training <- sample(1:nrow(Occurrences), round(split*nrow(Occurrences),0)) #create test-train split (split=percent train)
  training <- dismo::prepareData(x=raster.comb, p=Occurrences[id.training,c("Long", "Lat")], b=Occurrences[id.training,c("x", "y")])  #Use dismo prepare data to set up df
  testing <-dismo::prepareData(x=raster.comb, p=Occurrences[-id.training,c("Long", "Lat")], b=Occurrences[-id.training,c("x", "y")])    
  training<-na.omit(training)
  testing<-na.omit(testing)
  
  colnames(Occurrences)<-rep(c('Long','Lat'),2) #Change names
  testingPresPA<-rbind.data.frame(Occurrences[-id.training,1:2],Occurrences[-id.training,3:4])
  
  ##Maxent
  Sys.setenv(NOAWT=TRUE)
  Maxent.Model <-dismo::maxent(x = as.data.frame(training[,-1]), p = as.data.frame(training[,1])) #Train Maxent Model
  
  
  Maxent.0  <-dismo::predict(object = Maxent.Model, x = raster.comb, args='outputformat=cloglog') #Predict suitability according to trained model
  crs(Maxent.0) <- crs(SC_boundary_vect)
  Maxent.eval <-dismo::evaluate(p = testing[testing[,"pb"]==1,-1], a = testing[testing[,"pb"]==0,-1], model = Maxent.Model)
  
  # Mask the raster to the shape of SC
  Maxent_masked <- mask(terra::rast(Maxent.0), SC_boundary_vect)
  Maxent_masked <- crop(Maxent_masked, c(-84, -78, 32, 35.5))
  cPer <- 100*length(Maxent_masked[Maxent_masked>0.75])/12096
  cPer <- round(cPer, 3)
  
  
  pdf(file= paste(sp, "_current.pdf", sep=""))
  plot(Maxent_masked, main=paste("Distribution Model of ", sp, ": Current Conditions", sep=""), xlab="Decimal Longitude", ylab="Decimal Latitude")
  lines(SC_boundary_vect, col = "black", lwd = 2)
  mtext(paste(cPer, "% of State area has suitability > 0.75"), side=2)
  mtext(paste("Model AUC of", round(Maxent.eval@auc, 3)), side=1)
  dev.off()
  
  Maxent.future  <-dismo::predict(object = Maxent.Model, x = project.comb, args='outputformat=cloglog')
  crs(Maxent.future) <- crs(SC_boundary_vect)
  Maxent.future_cut <- mask(terra::rast(Maxent.future), SC_boundary_vect)
  Maxent.future_cut <- crop(Maxent.future_cut, c(-84, -78, 32, 35.5))
  fPer <- 100*length(Maxent.future_cut[Maxent.future_cut>0.75])/12096
  fPer <- round(fPer, 3)
  
  pdf(file= paste(sp, "_future.pdf", sep=""))
  plot(Maxent.future_cut, main=paste("Distribution Model of ", sp, ": Future Conditions", sep=""), xlab="Decimal Longitude", ylab="Decimal Latitude")
  lines(SC_boundary_vect, col = "black", lwd = 2)
  points(x=Occ_plot$decimalLongitude, y=Occ_plot$decimalLatitude, pch=16, cex=.6, col="black")
  points(x=Occ_plot$decimalLongitude, y=Occ_plot$decimalLatitude, pch=16, cex=.5, col="red")
  length(Maxent.future_cut[Maxent.future_cut>0.75])
  mtext(paste(fPer, "% of State area has suitability > 0.75"), side=1)
  dev.off()
  
  
  plot(Maxent_masked, main=paste("Distribution Model of ", sp, ": Current Conditions", sep=""), xlab="Decimal Longitude", ylab="Decimal Latitude")
  lines(SC_boundary_vect, col = "black", lwd = 2)
  points(x=Occ_plot$decimalLongitude, y=Occ_plot$decimalLatitude, pch=16, cex=.6, col="black")
  points(x=Occ_plot$decimalLongitude, y=Occ_plot$decimalLatitude, pch=16, cex=.5, col="red")
  mtext(paste(cPer, "% of State area has suitability > 0.75"), side=4)
  text(x = -83, y = 32.7, labels = paste("Model AUC of", round(Maxent.eval@auc, 3)))
  
  plot(Maxent.future_cut, main=paste("Distribution Model of ", sp, ": Future Conditions", sep=""), xlab="Decimal Longitude", ylab="Decimal Latitude")
  lines(SC_boundary_vect, col = "black", lwd = 2)
  points(x=Occ_plot$decimalLongitude, y=Occ_plot$decimalLatitude, pch=16, cex=.6, col="black")
  points(x=Occ_plot$decimalLongitude, y=Occ_plot$decimalLatitude, pch=16, cex=.5, col="red")
  length(Maxent.future_cut[Maxent.future_cut>0.75])
  mtext(paste(fPer, "% of State area has suitability > 0.75"), side=4)
}

#' Plot GBIF Occurrence Points in the Southeastern US
#'
#' Quickly visualize species occurrence data in the southeastern United States using base plotting.
#'
#' @param occ_df A `data.frame` containing occurrence data with columns `decimalLatitude`, `decimalLongitude`, and optionally `species`.
#' @param title A character string for the plot title. Defaults to "Occurrence Map".
#'
#' @return A base R plot with occurrence points.
#' @export
#'
#' @examples
#' \dontrun{
#' occ_data <- rgbif::occ_data(scientificName = "Asimina triloba", hasCoordinate = TRUE, limit = 500)$data
#' plot_occurrence_SE(occ_data, title = "Pawpaw Occurrences")
#' }
plot_occurrence_SE <- function(occ_df, title = "Occurrence Map", ptsz=0.5) {
  # Check required columns
  if (!all(c("decimalLatitude", "decimalLongitude") %in% colnames(occ_df))) {
    stop("occ_df must include 'decimalLatitude' and 'decimalLongitude' columns")
  }
  
  # Get SE US base map
  se_states <- rnaturalearth::ne_states(country = "United States of America", returnclass = "sf") |>
    dplyr::filter(name %in% c("South Carolina", "North Carolina", "Georgia", "Florida", "Alabama", 
                              "Tennessee", "Mississippi", "Louisiana"))
  
  # Plot background
  plot(se_states$geometry, col = "gray95", border = "gray40", main = title,
       xlim = c(-92, -75), ylim = c(24, 37), axes = TRUE, xlab = "Longitude", ylab = "Latitude")
  
  # Plot points (colored if species present)
  if ("species" %in% colnames(occ_df)) {
    species_list <- unique(occ_df$species)
    cols <- rainbow(length(species_list))
    col_map <- setNames(cols, species_list)
    points(occ_df$decimalLongitude, occ_df$decimalLatitude,
           pch = 21, cex = 0.6, bg = col_map[occ_df$species])
    legend("topright", legend = species_list, pt.bg = cols, pch = 21, cex = 0.7, bty = "n")
  } else {
    points(occ_df$decimalLongitude, occ_df$decimalLatitude, pch = 16, col = "red", cex = ptsz) #interior
  }
}
